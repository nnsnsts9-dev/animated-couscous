package com.duel.commands;

import com.duel.DuelPlugin;
import com.duel.models.DuelSession;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.stream.Collectors;

public class SpectateCommand implements CommandExecutor, TabCompleter {

    private final DuelPlugin plugin;
    private final Map<UUID, SpectatorData> spectators = new ConcurrentHashMap<>();

    public SpectateCommand(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player spectator)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }

        if (args.length == 0) {
            if (isSpectating(spectator)) stopSpectating(spectator);
            else spectator.sendMessage(color("&cUsage: /spectate <player>"));
            return true;
        }

        if (plugin.getDuelManager().isInDuel(spectator)) {
            spectator.sendMessage(color("&c⚔ You cannot spectate while in a duel!"));
            return true;
        }

        if (isSpectating(spectator)) {
            spectator.sendMessage(color("&c⚔ You are already spectating. Type /spectate to exit."));
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);

        if (target == null) {
            spectator.sendMessage(color("&c⚔ Player &e" + args[0] + " &cis offline."));
            return true;
        }

        if (target.equals(spectator)) {
            spectator.sendMessage(color("&c⚔ You cannot spectate yourself!"));
            return true;
        }

        if (!plugin.getDuelManager().isInDuel(target)) {
            spectator.sendMessage(color("&c⚔ &e" + target.getName() + " &cis not currently in a duel."));
            return true;
        }

        DuelSession session = plugin.getDuelManager().getSession(target);

        if (session.getState() == DuelSession.State.ENDED) {
            spectator.sendMessage(color("&c⚔ The duel has just ended."));
            return true;
        }

        startSpectating(spectator, target, session);
        return true;
    }

    private void startSpectating(Player spectator, Player target, DuelSession session) {
        spectators.put(spectator.getUniqueId(), new SpectatorData(spectator.getLocation(), spectator.getGameMode()));
        spectator.setGameMode(GameMode.SPECTATOR);

        World duelWorld = Bukkit.getWorld(session.getCopiedWorldName());
        if (duelWorld != null) spectator.teleport(target.getLocation().clone().add(0, 3, 0));
        else spectator.teleport(target.getLocation().clone().add(0, 3, 0));

        spectator.setSpectatorTarget(target);
        spectator.sendMessage(color("&a👁 Now spectating: &e" + target.getName()
                + " &7vs &e" + session.getOpponent(target).getName()));
        spectator.sendMessage(color("&7Type &f/spectate &7to exit spectator mode."));
    }

    public void stopSpectating(Player spectator) {
        SpectatorData data = spectators.remove(spectator.getUniqueId());
        if (data == null) return;
        spectator.setSpectatorTarget(null);
        spectator.setGameMode(data.previousGameMode());
        spectator.teleport(data.returnLocation());
        spectator.sendMessage(color("&a👁 You have exited spectator mode."));
    }

    public void ejectSpectators(DuelSession session) {
        World duelWorld = Bukkit.getWorld(session.getCopiedWorldName());
        if (duelWorld == null) return;
        new ArrayList<>(spectators.keySet()).forEach(uuid -> {
            Player sp = Bukkit.getPlayer(uuid);
            if (sp != null && sp.getWorld().equals(duelWorld)) {
                sp.sendMessage(color("&6👁 The duel has ended — you have been removed from spectator mode."));
                stopSpectating(sp);
            }
        });
    }

    public boolean isSpectating(Player player) {
        return spectators.containsKey(player.getUniqueId());
    }

    public void spectate(Player spectator, Player target) {
        if (spectator.equals(target) || plugin.getDuelManager().isInDuel(spectator) || isSpectating(spectator)) return;
        DuelSession session = plugin.getDuelManager().getSession(target);
        if (session == null || session.getState() == DuelSession.State.ENDED) {
            spectator.sendMessage(color("&c⚔ This player is not in an active duel."));
            return;
        }
        startSpectating(spectator, target, session);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        if (args.length == 1) {
            return Bukkit.getOnlinePlayers().stream()
                    .filter(p -> plugin.getDuelManager().isInDuel(p))
                    .filter(p -> !p.getName().equals(sender.getName()))
                    .map(Player::getName)
                    .filter(name -> name.toLowerCase().startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        return new ArrayList<>();
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    private record SpectatorData(Location returnLocation, GameMode previousGameMode) {}
}
