package com.duel.listeners;

import com.duel.DuelPlugin;
import com.duel.models.Arena;
import com.duel.models.DuelSession;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public class DuelListener implements Listener {

    private final DuelPlugin plugin;

    public DuelListener(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    // ─────────────────────────────────────────
    //  Death → end duel
    // ─────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        // Party duel يتعامل معها PartyDuelListener
        if (plugin.getPartyDuelManager().isInPartyDuel(dead)) return;
        if (!plugin.getDuelManager().isInDuel(dead)) return;

        // Suppress death message and drops
        event.setDeathMessage(null);
        event.getDrops().clear();
        event.setDroppedExp(0);

        // Trigger duel end
        plugin.getDuelManager().onPlayerDeath(dead);
    }

    // ─────────────────────────────────────────
    //  Respawn → send to arena (handled by DuelManager already)
    // ─────────────────────────────────────────

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        // DuelManager handles teleport; respawn can proceed normally
    }

    // ─────────────────────────────────────────
    //  Block break — enforce arena setting
    // ─────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (player.hasPermission("duelplugin.admin")) return;

        DuelSession session = plugin.getDuelManager().getSession(player);
        if (session == null) return;

        Arena arena = session.getArena();
        if (arena == null) return;

        org.bukkit.Location loc = event.getBlock().getLocation();
        boolean isPlaced = session.isPlacedBlock(loc);

        if (isPlaced) {
            // بلوكة مبنية أثناء المباراة
            if (!arena.isAllowBreakPlaced()) {
                event.setCancelled(true);
                return;
            }
            // مسموح بتكسير المبنية — نشيلها من التتبع
            session.untrackBlock(loc);
        } else {
            // بلوكة أصلية من الماب
            if (!arena.isAllowBreaking()) {
                event.setCancelled(true);
            }
        }
    }

    // ─────────────────────────────────────────
    //  Block place — enforce arena setting
    // ─────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (player.hasPermission("duelplugin.admin")) return;

        DuelSession session = plugin.getDuelManager().getSession(player);
        if (session == null) return;

        Arena arena = session.getArena();
        if (arena == null) return;

        if (!arena.isAllowBuilding()) {
            event.setCancelled(true);
            return;
        }

        // منع البناء أكثر من 30 بلوك فوق Y الإسبون
        org.bukkit.Location spawnLoc = session.getPlayerSpawn(player);
        if (spawnLoc != null && event.getBlock().getY() - spawnLoc.getBlockY() > 30) {
            event.setCancelled(true);
            return;
        }

        // تتبع البلوكة المبنية
        session.trackPlacedBlock(event.getBlock().getLocation(), player);
    }

    // ─────────────────────────────────────────
    //  PvP — only allow damage within active duels
    // ─────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;
        if (!(event.getDamager() instanceof Player attacker)) return;

        // إذا أي منهم في party duel — PartyDuelListener تتعامل معها
        if (plugin.getPartyDuelManager().isInPartyDuel(attacker) ||
            plugin.getPartyDuelManager().isInPartyDuel(victim)) return;

        boolean attackerInDuel = plugin.getDuelManager().isInDuel(attacker);
        boolean victimInDuel   = plugin.getDuelManager().isInDuel(victim);

        // If neither is in a duel — let normal server rules apply
        if (!attackerInDuel && !victimInDuel) return;

        // If both are in a duel, check they're in the same session
        if (attackerInDuel && victimInDuel) {
            DuelSession aSession = plugin.getDuelManager().getSession(attacker);
            DuelSession vSession = plugin.getDuelManager().getSession(victim);

            if (aSession != null && aSession.equals(vSession)
                    && aSession.getState() == DuelSession.State.FIGHTING) {
                return; // valid duel fight — allow damage
            }
        }

        // Otherwise cancel
        event.setCancelled(true);
    }
}
