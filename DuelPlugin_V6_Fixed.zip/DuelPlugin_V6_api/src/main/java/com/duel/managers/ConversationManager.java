package com.duel.managers;

import com.duel.DuelPlugin;
import com.duel.models.Arena;
import com.duel.utils.ItemUtils;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;

import java.util.*;

/**
 * Multi-step arena setup:
 * 1. WORLD_COUNT      — how many worlds?
 * 2. WORLD_NAMES      — type each world name
 * 3. SPAWN_SELECTION  — golden axe to set P1/P2 spawns per world
 *
 * World settings (break/build/difficulty) are set in ArenaEditorGUI before Save.
 */
public class ConversationManager implements Listener {

    private final DuelPlugin plugin;

    enum Step { WORLD_COUNT, WORLD_NAMES, SPAWN_SELECTION }

    private final Map<UUID, Step>         step            = new HashMap<>();
    private final Map<UUID, Arena>        arenaMap        = new HashMap<>();
    private final Map<UUID, Integer>      worldCount      = new HashMap<>();
    private final Map<UUID, List<String>> collectedWorlds = new HashMap<>();
    private final Map<UUID, Integer>      worldIndex      = new HashMap<>();
    private final Map<UUID, Integer>      spawnIndex      = new HashMap<>();

    public ConversationManager(DuelPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    // ─────────────────────────────────────────
    //  Entry point
    // ─────────────────────────────────────────

    public void startWorldSetup(Player admin, Arena arena) {
        arenaMap.put(admin.getUniqueId(), arena);
        step.put(admin.getUniqueId(), Step.WORLD_COUNT);
        admin.sendMessage(color("&7━━━━━━━━━━━━━━━━━━━━━━━━"));
        admin.sendMessage(color("&b⚙ Arena Setup &8— &e" + arena.getId()));
        admin.sendMessage(color("&7How many worlds does this arena have?"));
        admin.sendMessage(color("&8(type a number in chat)"));
    }

    // ─────────────────────────────────────────
    //  Chat listener
    // ─────────────────────────────────────────

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID uid = player.getUniqueId();
        if (!step.containsKey(uid)) return;
        event.setCancelled(true);
        String msg = event.getMessage().trim();
        Step current = step.get(uid);
        if (current == Step.WORLD_COUNT) handleWorldCount(player, msg);
        else if (current == Step.WORLD_NAMES) handleWorldName(player, msg);
    }

    private void handleWorldCount(Player admin, String msg) {
        int count;
        try {
            count = Integer.parseInt(msg);
            if (count <= 0 || count > 20) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            admin.sendMessage(color("&cInvalid number! Please enter a number between 1 and 20."));
            return;
        }
        worldCount.put(admin.getUniqueId(), count);
        collectedWorlds.put(admin.getUniqueId(), new ArrayList<>());
        step.put(admin.getUniqueId(), Step.WORLD_NAMES);
        admin.sendMessage(color("&aGreat! Now type the name of world &e#1&a:"));
    }

    private void handleWorldName(Player admin, String msg) {
        UUID uid = admin.getUniqueId();
        List<String> worlds = collectedWorlds.get(uid);
        int total = worldCount.get(uid);
        World w = Bukkit.getWorld(msg);
        if (w == null) {
            admin.sendMessage(color("&cWorld '&e" + msg + "&c' not found! Make sure it's loaded with Multiverse."));
            admin.sendMessage(color("&7Try again:"));
            return;
        }
        worlds.add(msg);
        int next = worlds.size() + 1;
        if (worlds.size() < total) {
            admin.sendMessage(color("&a✔ Added world &e" + msg + "&a. Now type world &e#" + next + "&a:"));
        } else {
            Arena arena = arenaMap.get(uid);
            arena.getWorlds().clear();
            arena.getWorlds().addAll(worlds);
            admin.sendMessage(color("&a✔ All " + total + " worlds saved!"));
            // Apply world settings from arena (already set in ArenaEditorGUI)
            applyWorldSettings(arena);
            step.put(uid, Step.SPAWN_SELECTION);
            worldIndex.put(uid, 0);
            spawnIndex.put(uid, 0);
            Bukkit.getScheduler().runTaskLater(plugin, () -> startSpawnSelection(admin), 5L);
        }
    }

    // ─────────────────────────────────────────
    //  Spawn selection
    // ─────────────────────────────────────────

    private void startSpawnSelection(Player admin) {
        UUID uid = admin.getUniqueId();
        Arena arena = arenaMap.get(uid);
        List<String> worlds = collectedWorlds.get(uid);
        int wIdx = worldIndex.get(uid);
        int sIdx = spawnIndex.getOrDefault(uid, 0);

        if (wIdx >= worlds.size()) {
            finishSetup(admin);
            return;
        }

        String worldName = worlds.get(wIdx);
        World world = Bukkit.getWorld(worldName);
        String playerLabel = sIdx == 0 ? "&aP1 &7(Player 1)" : "&cP2 &7(Player 2)";

        admin.teleport(world.getSpawnLocation());
        admin.getInventory().clear();
        admin.getInventory().addItem(ItemUtils.getSpawnAxe(worldName));
        admin.sendMessage(color("&7━━━━━━━━━━━━━━━━━━━━━━━━"));
        admin.sendMessage(color("&bWorld: &e" + worldName + " &8(" + (wIdx + 1) + "/" + worlds.size() + ")"
                + " &8— Spawn " + playerLabel));
        admin.sendMessage(color("&7Stand where you want the &e" + (sIdx == 0 ? "P1" : "P2")
                + " spawn&7 and &aright-click the golden axe&7."));
    }

    @EventHandler
    public void onAxeClick(PlayerInteractEvent event) {
        Player admin = event.getPlayer();
        UUID uid = admin.getUniqueId();
        if (!step.containsKey(uid) || step.get(uid) != Step.SPAWN_SELECTION) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        var item = admin.getInventory().getItemInMainHand();
        if (item.getType() != org.bukkit.Material.GOLDEN_AXE) return;
        event.setCancelled(true);

        Arena arena = arenaMap.get(uid);
        List<String> worlds = collectedWorlds.get(uid);
        int idx = worldIndex.get(uid);
        String worldName = worlds.get(idx);
        int sIdx = spawnIndex.getOrDefault(uid, 0);
        String playerLabel = sIdx == 0 ? "P1" : "P2";

        arena.addSpawn(worldName, admin.getLocation().clone());
        admin.getInventory().removeItem(item);
        admin.sendMessage(color("&a✔ " + playerLabel + " spawn set for world &e" + worldName + "&a!"));

        if (sIdx == 0) {
            spawnIndex.put(uid, 1);
            Bukkit.getScheduler().runTaskLater(plugin, () -> startSpawnSelection(admin), 5L);
        } else {
            spawnIndex.put(uid, 0);
            worldIndex.put(uid, idx + 1);
            Bukkit.getScheduler().runTaskLater(plugin, () -> startSpawnSelection(admin), 10L);
        }
    }

    // ─────────────────────────────────────────
    //  Finish
    // ─────────────────────────────────────────

    private void finishSetup(Player admin) {
        UUID uid = admin.getUniqueId();
        Arena arena = arenaMap.get(uid);
        plugin.getArenaManager().saveArena(arena);
        cleanup(uid);

        admin.sendMessage(color("&7━━━━━━━━━━━━━━━━━━━━━━━━"));
        admin.sendMessage(color("&a✔✔ Arena &e" + arena.getId() + " &ahas been fully configured!"));
        admin.sendMessage(color("&7Worlds: &f" + arena.getWorlds().size()
                + " &7| Spawns: &f" + arena.getSpawnPoints().size()));
        admin.sendMessage(color("&7Breaking: &f" + (arena.isAllowBreaking() ? "Yes" : "No")
                + " &7| Building: &f" + (arena.isAllowBuilding() ? "Yes" : "No")
                + " &7| Difficulty: &f" + arena.getDifficulty()));
        admin.sendMessage(color("&7Use &f/GUI KIT " + arena.getId() + " &7to set the kit."));
        admin.sendMessage(color("&7━━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    private void applyWorldSettings(Arena arena) {
        org.bukkit.Difficulty diff = switch (arena.getDifficulty()) {
            case "easy" -> org.bukkit.Difficulty.EASY;
            case "hard" -> org.bukkit.Difficulty.HARD;
            default     -> org.bukkit.Difficulty.NORMAL;
        };
        for (String wName : arena.getWorlds()) {
            World w = Bukkit.getWorld(wName);
            if (w == null) continue;
            w.setDifficulty(diff);
            w.setGameRule(org.bukkit.GameRule.DO_TILE_DROPS, arena.isAllowBreaking());
        }
    }

    private void cleanup(UUID uid) {
        step.remove(uid);
        arenaMap.remove(uid);
        worldCount.remove(uid);
        collectedWorlds.remove(uid);
        worldIndex.remove(uid);
        spawnIndex.remove(uid);
    }

    public boolean isInConversation(Player player) {
        return step.containsKey(player.getUniqueId());
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}
