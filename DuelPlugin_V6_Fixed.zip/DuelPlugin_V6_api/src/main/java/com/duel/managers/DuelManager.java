package com.duel.managers;

import com.duel.DuelPlugin;
import com.duel.models.Arena;
import com.duel.models.DuelSession;
import com.duel.models.Kit;
import com.duel.trim.TrimManager;
import com.duel.utils.SoundUtils;
import com.duel.utils.TitleUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.*;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class DuelManager {

    private final DuelPlugin plugin;
    // sessionId → session
    private final Map<UUID, DuelSession> sessions = new HashMap<>();
    // player UUID → session
    private final Map<UUID, DuelSession> playerSession = new HashMap<>();

    public DuelManager(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    // ─────────────────────────────────────────
    //  Start a duel between two players
    // ─────────────────────────────────────────

    public void startDuel(Player p1, Player p2, Arena arena) {
        String templateWorld = arena.getRandomWorld();
        if (templateWorld == null) {
            p1.sendMessage(color("&cNo worlds configured for this arena!"));
            p2.sendMessage(color("&cNo worlds configured for this arena!"));
            return;
        }

        String copyName = plugin.getConfig().getString("settings.arena-copy-prefix", "duel_arena_")
                + arena.getId() + "_" + System.currentTimeMillis();

        // Notify players
        p1.sendMessage(color("&a⚔ Match found! Preparing arena..."));
        p2.sendMessage(color("&a⚔ Match found! Preparing arena..."));

        // Lock movement immediately
        p1.setWalkSpeed(0f);
        p2.setWalkSpeed(0f);
        p1.setFlySpeed(0f);
        p2.setFlySpeed(0f);

        // Clone world async (Multiverse handles this), then schedule duel setup
        final String finalTemplateWorld = templateWorld;
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            plugin.getArenaManager().copyWorld(finalTemplateWorld, copyName);

            // Multiverse clone is async; wait until world loads
            waitForWorld(copyName, () -> onWorldReady(p1, p2, arena, finalTemplateWorld, copyName));
        });
    }

    /** Poll every 10 ticks until the world is loaded, then run callback */
    private void waitForWorld(String worldName, Runnable callback) {
        final int[] attempts = {0};
        plugin.getServer().getScheduler().runTaskTimer(plugin, task -> {
            attempts[0]++;
            World w = Bukkit.getWorld(worldName);
            if (w != null) {
                task.cancel();
                callback.run();
            } else if (attempts[0] > 200) { // 200 * 10 ticks = 1000 ticks = 50s timeout
                task.cancel();
                plugin.getLogger().warning("World copy timed out: " + worldName);
            }
        }, 10L, 10L);
    }

    private void onWorldReady(Player p1, Player p2, Arena arena, String templateWorld, String copyName) {
        World world = Bukkit.getWorld(copyName);
        if (world == null) return;

        // Get spawn locations — P1 = index 0, P2 = index 1
        Location spawn1 = getSpawn(arena, templateWorld, world, 0);
        Location spawn2 = getSpawn(arena, templateWorld, world, 1);

        // Teleport
        p1.teleport(spawn1);
        p2.teleport(spawn2);

        // Create session
        DuelSession session = new DuelSession(p1, p2, arena, copyName);
        session.setPlayerSpawn(p1, spawn1);
        session.setPlayerSpawn(p2, spawn2);
        sessions.put(session.getSessionId(), session);
        playerSession.put(p1.getUniqueId(), session);
        playerSession.put(p2.getUniqueId(), session);

        // Apply kits — player personal arrangement takes priority over arena default
        String kitName = arena.getKitName() != null ? arena.getKitName() : arena.getId();
        Kit defaultKit = plugin.getKitManager().getKit(kitName);
        applyPersonalOrDefault(p1, arena.getId(), defaultKit);
        applyPersonalOrDefault(p2, arena.getId(), defaultKit);

        // Apply saved armor trims on top of the kit (scoped to this arena)
        applyTrimsToPlayer(p1, arena.getId());
        applyTrimsToPlayer(p2, arena.getId());

        // Freeze players
        p1.setInvulnerable(true);
        p2.setInvulnerable(true);

        // Force both players to see each other, even if "Hide Players" is enabled
        p1.showPlayer(plugin, p2);
        p2.showPlayer(plugin, p1);

        // ── عزل الـ TAB — يشوف كل لاعب بس خصمه ──
        plugin.getTabIsolationManager().isolate(List.of(p1, p2));

        // Countdown
        startCountdown(session, p1, p2);
    }

    private Location getSpawn(Arena arena, String templateWorldName, World copiedWorld, int playerIndex) {
        // Try exact template world name first
        Location loc = arena.getSpawn(templateWorldName, playerIndex);

        // Fallback: try any stored world's spawns
        if (loc == null) {
            for (List<org.bukkit.Location> spawns : arena.getSpawnPoints().values()) {
                if (spawns.size() > playerIndex) { loc = spawns.get(playerIndex); break; }
                if (!spawns.isEmpty())            { loc = spawns.get(0); break; }
            }
        }

        if (loc == null) {
            plugin.getLogger().warning("[DuelManager] No spawn found for arena '"
                    + arena.getId() + "' world '" + templateWorldName + "' — using world spawn.");
            return copiedWorld.getSpawnLocation();
        }

        // Always adapt to the copied world (handles null-world lazy locations too)
        return new Location(copiedWorld, loc.getX(), loc.getY(), loc.getZ(), loc.getYaw(), loc.getPitch());
    }

    private void startCountdown(DuelSession session, Player p1, Player p2) {
        int seconds = plugin.getConfig().getInt("settings.countdown-seconds", 5);
        AtomicInteger countdown = new AtomicInteger(seconds);

        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            // Bug fix: إذا انتهت الجلسة أثناء الـ countdown (disconnect) — نوقف مباشرةً
            if (session.getState() == DuelSession.State.ENDED) return;
            int current = countdown.getAndDecrement();
            if (current <= 0) return;
            if (p1.isOnline()) { TitleUtils.sendCountdown(p1, current); SoundUtils.playCountdown(p1); }
            if (p2.isOnline()) { TitleUtils.sendCountdown(p2, current); SoundUtils.playCountdown(p2); }
        }, 0L, 20L);

        // نحفظ الـ task في الجلسة حتى يمكن إلغاؤها لو انتهت المباراة مبكراً
        session.setCountdownTask(task);

        // Schedule GO after countdown
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            task.cancel();
            session.setCountdownTask(null);

            // Bug fix: لو انتهت المباراة بالفعل (disconnect أثناء countdown) — لا تفعل شيئاً
            if (session.getState() == DuelSession.State.ENDED) return;

            // Unfreeze
            if (p1.isOnline()) { p1.setInvulnerable(false); p1.setWalkSpeed(0.2f); p1.setFlySpeed(0.1f); }
            if (p2.isOnline()) { p2.setInvulnerable(false); p2.setWalkSpeed(0.2f); p2.setFlySpeed(0.1f); }

            session.setState(DuelSession.State.FIGHTING);
            session.markStarted();

            // ── Scoreboard ping live ──
            plugin.getDuelScoreboardManager().start(session);

            if (p1.isOnline()) { TitleUtils.sendGo(p1); SoundUtils.playGo(p1); }
            if (p2.isOnline()) { TitleUtils.sendGo(p2); SoundUtils.playGo(p2); }

        }, (long) (seconds + 1) * 20L);
    }

    // ─────────────────────────────────────────
    //  End duel
    // ─────────────────────────────────────────

    public void endDuel(DuelSession session, Player winner) {
        if (session.getState() == DuelSession.State.ENDED) return;
        session.setState(DuelSession.State.ENDED);
        // Bug fix: إلغاء الـ countdown task إذا مات اللاعب خلال العدّ التنازلي
        if (session.getCountdownTask() != null) {
            session.getCountdownTask().cancel();
            session.setCountdownTask(null);
        }
        session.setWinner(winner);

        // ── إزالة عزل الـ TAB ──
        plugin.getTabIsolationManager().restore(session.getPlayer1());
        plugin.getTabIsolationManager().restore(session.getPlayer2());

        // ── إيقاف الـ Scoreboard ──
        plugin.getDuelScoreboardManager().stop(session);

        Player loser = session.getLoser();

        // Eject spectators from the duel world before cleanup
        plugin.getSpectateCommand().ejectSpectators(session);

        // Record stats
        plugin.getStatsManager().recordWin(winner.getUniqueId(), winner.getName(), session.getArena().getId());
        plugin.getStatsManager().recordLoss(loser.getUniqueId(), loser.getName(), session.getArena().getId());

        // Refresh leaderboard holograms
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> plugin.getHologramManager().refreshAll(), 20L);

        // Show results — فقط للاعبين الـ online
        if (winner.isOnline()) {
            TitleUtils.sendWinner(winner);
            SoundUtils.playWinner(winner);
        }
        if (loser.isOnline()) {
            TitleUtils.sendLoser(loser);
            SoundUtils.playLoser(loser);
        }

        // ── Clear inventories immediately so kit doesn't carry over to spawn ──
        if (winner.isOnline()) {
            winner.getInventory().clear();
            winner.setGameMode(GameMode.ADVENTURE);
        }
        if (loser.isOnline()) {
            loser.getInventory().clear();
            loser.setGameMode(GameMode.SPECTATOR);
        }

        // ── Offer rematch AFTER clearing inventories ──
        int rematchDelay = plugin.getConfig().getInt("settings.winner-delay-seconds", 5);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (winner.isOnline() && loser.isOnline()) {
                plugin.getRematchManager().offer(winner, loser, session.getArena());
            }
        }, rematchDelay * 20L);

        // Winner → send to spawn if no rematch offered (one-shot fallback, runs 2 ticks AFTER offer)
        // المشكلة السابقة: rematchDelay و winnerDelay كانوا نفس القيمة فكان Bukkit أحياناً يشغّل
        // الـ spawn-fallback قبل offer()، فيشوف isOffering=false ويطير للسبون بدون hotbar لأن
        // RematchManager ما أُبلغ بعد. الحل: نزيد تأخير الـ fallback بـ 2 tick فقط لضمان الترتيب.
        int winnerDelay = plugin.getConfig().getInt("settings.winner-delay-seconds", 5);
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (!winner.isOnline()) return;
            // If rematch is pending, RematchManager will handle teleport + hotbar
            if (plugin.getRematchManager().isOffering(winner)) return;
            // No rematch offered — send to spawn now
            winner.setGameMode(GameMode.SURVIVAL);
            winner.teleport(getServerSpawn());
            giveMenuSword(winner);
            plugin.getSettingsManager().applyEffect(winner,
                    com.duel.managers.SettingsManager.Setting.HIDE_PLAYERS,
                    plugin.getSettingsManager().isEnabled(winner.getUniqueId(),
                            com.duel.managers.SettingsManager.Setting.HIDE_PLAYERS));
        }, winnerDelay * 20L + 2L); // +2 ticks بعد offer لضمان isOffering() صحيحة

        // Loser — لو offline ما نحتاج نفعل شيء (يرجع للسبون عند rejoin)
        int loserDelay = plugin.getConfig().getInt("settings.loser-spectator-seconds", 5);
        if (loser.isOnline()) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (!loser.isOnline()) return;
                // If rematch is pending, RematchManager will handle teleport + hotbar
                if (plugin.getRematchManager().isOffering(loser)) return;
                // No rematch offered — send to spawn now
                loser.setGameMode(GameMode.SURVIVAL);
                loser.teleport(getServerSpawn());
                giveMenuSword(loser);
                plugin.getSettingsManager().applyEffect(loser,
                        com.duel.managers.SettingsManager.Setting.HIDE_PLAYERS,
                        plugin.getSettingsManager().isEnabled(loser.getUniqueId(),
                                com.duel.managers.SettingsManager.Setting.HIDE_PLAYERS));
            }, loserDelay * 20L + 2L); // +2 ticks بعد offer لضمان isOffering() صحيحة
        }

        // Clean up session and delete world (after both have been teleported)
        int cleanupDelay = Math.max(winnerDelay, loserDelay) + 2;
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            sessions.remove(session.getSessionId());
            playerSession.remove(session.getPlayer1().getUniqueId());
            playerSession.remove(session.getPlayer2().getUniqueId());

            // Safety: teleport anyone still in the duel world to server spawn
            String copyName = session.getCopiedWorldName();
            org.bukkit.World duelWorld = org.bukkit.Bukkit.getWorld(copyName);
            if (duelWorld != null && !duelWorld.getPlayers().isEmpty()) {
                org.bukkit.Location fallback = getServerSpawn();
                for (Player stuckPlayer : new java.util.ArrayList<>(duelWorld.getPlayers())) {
                    stuckPlayer.teleport(fallback);
                }
                // Give Bukkit one more tick to process teleports before deleting
                plugin.getServer().getScheduler().runTaskLater(plugin, () ->
                        plugin.getArenaManager().deleteWorld(copyName), 5L);
            } else {
                plugin.getArenaManager().deleteWorld(copyName);
            }
        }, cleanupDelay * 20L);
    }

    /**
     * يُنظف الجلسة بدون إعلان فائز — يُستخدم لما الاثنين offline.
     */
    public void forceCleanup(com.duel.models.DuelSession session) {
        if (session.getState() == com.duel.models.DuelSession.State.ENDED) return;
        session.setState(com.duel.models.DuelSession.State.ENDED);
        if (session.getPingTask() != null) session.getPingTask().cancel();
        sessions.remove(session.getSessionId());
        playerSession.remove(session.getPlayer1().getUniqueId());
        playerSession.remove(session.getPlayer2().getUniqueId());

        // Teleport any players still in the duel world before deleting
        String copyName = session.getCopiedWorldName();
        org.bukkit.World duelWorld = org.bukkit.Bukkit.getWorld(copyName);
        if (duelWorld != null) {
            org.bukkit.Location fallback = getServerSpawn();
            for (Player stuckPlayer : new java.util.ArrayList<>(duelWorld.getPlayers())) {
                stuckPlayer.teleport(fallback);
            }
            plugin.getServer().getScheduler().runTaskLater(plugin, () ->
                    plugin.getArenaManager().deleteWorld(copyName), 5L);
        } else {
            plugin.getArenaManager().deleteWorld(copyName);
        }
    }

    public int getActiveCountForArena(String arenaId) {
        return (int) sessions.values().stream()
                .filter(s -> s.getState() == DuelSession.State.FIGHTING
                          && s.getArena().getId().equalsIgnoreCase(arenaId))
                .count();
    }

    public java.util.Collection<DuelSession> getAllActiveSessions() {
        return sessions.values().stream()
                .filter(s -> s.getState() == DuelSession.State.FIGHTING)
                .toList();
    }

    public void cleanupAll() {
        for (DuelSession session : new ArrayList<>(sessions.values())) {
            plugin.getArenaManager().deleteWorld(session.getCopiedWorldName());
        }
        sessions.clear();
        playerSession.clear();
    }

    // ─────────────────────────────────────────
    //  Helpers
    // ─────────────────────────────────────────

    public DuelSession getSession(Player player) {
        return playerSession.get(player.getUniqueId());
    }

    public boolean isInDuel(Player player) {
        return playerSession.containsKey(player.getUniqueId());
    }

    private Location getServerSpawn() {
        return plugin.getSpawnManager().getSpawn();
    }

    private void giveMenuSword(Player player) {
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            plugin.getPlayerJoinListener().giveDuelSword(player);
            // Restore party hotbar items if player is in a party
            plugin.getPartyManager().refreshHotbar(player);
        }, 5L);
    }

    /** Apply the player's personal kit arrangement if they have one, else the arena default. */
    private void applyPersonalOrDefault(Player player, String arenaId, Kit defaultKit) {
        org.bukkit.inventory.ItemStack[] personal =
                plugin.getPlayerKitManager().getPlayerKit(player.getUniqueId(), arenaId);

        if (personal != null) {
            // Apply personal arrangement directly
            player.getInventory().clear();
            com.duel.models.Kit personalKit = new com.duel.models.Kit("__personal__", personal);
            plugin.getKitManager().applyKit(player, personalKit);
        } else if (defaultKit != null) {
            plugin.getKitManager().applyKit(player, defaultKit);
        }
    }

    /**
     * Apply the player's saved armor trims (for the given arena) to whatever armor
     * they currently have equipped. Must be called AFTER applyPersonalOrDefault so
     * armor is already set.
     */
    private void applyTrimsToPlayer(Player player, String arenaId) {
        org.bukkit.inventory.PlayerInventory inv = player.getInventory();
        TrimManager trimManager = plugin.getTrimManager();
        UUID uuid = player.getUniqueId();

        org.bukkit.inventory.ItemStack[] trimmed = trimManager.applyTrims(
            uuid,
            arenaId,
            inv.getHelmet(),
            inv.getChestplate(),
            inv.getLeggings(),
            inv.getBoots()
        );
        // trimmed order: HELMET, CHESTPLATE, LEGGINGS, BOOTS
        if (trimmed[0] != null) inv.setHelmet(trimmed[0]);
        if (trimmed[1] != null) inv.setChestplate(trimmed[1]);
        if (trimmed[2] != null) inv.setLeggings(trimmed[2]);
        if (trimmed[3] != null) inv.setBoots(trimmed[3]);
        player.updateInventory();
    }

    /** Called from DuelListener when a player dies in a duel */
    public void onPlayerDeath(Player dead) {
        DuelSession session = getSession(dead);
        if (session == null || session.getState() != DuelSession.State.FIGHTING) return;
        Player opponent = session.getOpponent(dead);
        endDuel(session, opponent);
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}
